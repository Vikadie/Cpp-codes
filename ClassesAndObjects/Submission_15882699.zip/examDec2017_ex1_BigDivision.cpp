#include <iostream>
#include <algorithm>
#include <set>
#include <sstream>
#include <string>


using namespace std;

int main() {
	string startNum, endNum;

	string str;
	getline(cin, startNum);
	//istringstream in(str);
	//startNum = BigInt(str);
	getline(cin, endNum);
	//endNum = BigInt(str);

	long long int sn, en;
	bool diff = false;
	string start = "", end = "", leading = "";
	if (startNum.size() == endNum.size())
		for (int i = 0; i < startNum.size(); i++)
			if (!diff && startNum[i] == endNum[i]) {
				leading += startNum[i];
			}
			else {
				start += (startNum[i]);
				end += endNum[i];
				diff = true;
			}
	else {
        start = startNum;
        end = endNum;
	}
	sn = stoi(start);
	en = stoi(end);
	//cout << startNum << " " << endNum;
	set <long long int> ans;
	for (long long int i = sn; i < en; i += 1) {
		if (i % 45 == 0)
			ans.insert(i);
	}

	for (auto j : ans)
		cout << leading << j << endl;
		
	return 0;
}