#include <iostream>
#include <algorithm>
#include <set>
#include <sstream>
#include <string>


using namespace std;

int main() {
	string startNum, endNum;

	string str;
	getline(cin, startNum);
	//istringstream in(str);
	//startNum = BigInt(str);
	getline(cin, endNum);
	//endNum = BigInt(str);

	long long int sn = 0, en = 0;
	bool diff = false;
	string start = "", end = "", leading = "";
	//if (startNum.size() == endNum.size())
		for (unsigned i = 0; i < endNum.size(); i++)
			if (!diff && startNum[i] == endNum[i]) {
				leading += startNum[i];
			}
			else {
				if (i < startNum.size())
					start += (startNum[i]);
				end += endNum[i];
				diff = true;
			}
	//else {
    //    start = startNum;
    //    end = endNum;
	//}
	if (start != "" && end != "") {
		sn = stoi(start);
		en = stoi(end);
		//cout << startNum << " " << endNum;
		set <long long int> ans;
		for (long long int i = sn; i < en; i += 1) {
			if (i % 45 == 0)
				ans.insert(i);
		}
		unsigned k = startNum.size() - leading.size();
		// if (ans.size() > 0)
		for (auto j : ans) {
			cout << leading;
			string str = to_string(j);
			while (str.size() < k)
				str = "0" + str;
			cout << str << endl;
		}
	}
	return 0;
}