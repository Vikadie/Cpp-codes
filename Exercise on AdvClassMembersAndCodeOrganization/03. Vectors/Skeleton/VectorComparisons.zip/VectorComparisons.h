#pragma once
#ifndef VECTOR_COMPARISONS_H
#define VECTOR_COMPARISONS_H

class VectorLengthComparer {
public:
	bool operator() (const Vector& a, const Vector& b) const {
		return a.getLength() < b.getLength();
	}
};

template<typename Vector, typename VectorLengthComparer>
class ReverseComparer {
public:
	bool operator() (const Vector& a, const Vector& b) const {
		return a.getLength() > b.getLength();
	}
};
#endif // !VECTOR_COMPARISONS_H
