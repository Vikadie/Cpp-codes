#pragma once
#ifndef ECHO_H
#define ECHO_H

#include <iostream>

extern bool echoOn;

void echo(std::string s);
#endif // !ECHO_H
