#include "Constants.h"

double PI = 3.14;