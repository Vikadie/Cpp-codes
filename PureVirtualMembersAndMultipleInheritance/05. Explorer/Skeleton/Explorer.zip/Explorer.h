#pragma once
#ifndef EXPLORER_H
#define EXPLORER_H

#include "Directory.h"
#include "File.h"

class Explorer {
	std::shared_ptr<Shortcuts> shortcuts; //sortcuts container
	std::vector<std::shared_ptr<FileSystemObject> > cutObject; //cut object container
	std::vector<std::shared_ptr<FileSystemObject> >& rootObjects; // root Folder container
	std::shared_ptr<Directory> currentParent;
public:
	Explorer(std::vector<std::shared_ptr<FileSystemObject> >& rootObjectsAddress): rootObjects(rootObjectsAddress), currentParent(nullptr), shortcuts(nullptr) {}

	void createFile(std::string filename, std::string content) {
		std::shared_ptr<FileSystemObject> newObject = std::make_shared<File>(filename, content);
		if (!currentParent) 
			rootObjects.push_back(newObject);
		else
			currentParent->add(newObject);
	}

	void createDirectory(std::string dirName) {
		std::shared_ptr<FileSystemObject> newObject = std::make_shared<Directory>(dirName);
		if (!currentParent)
			rootObjects.push_back(newObject);
		else
			currentParent->add(newObject);
	}

	void cut(std::string name) {
		// not used anymore std::shared_ptr<FileSystemObject> newObjectToCut = std::make_shared<FileSystemObject>(name);
		// check if it is in root
		if (!currentParent) {
			for (size_t i = 0; i < rootObjects.size(); i++)
				if (rootObjects[i]->getName() == name) {
					cutObject.push_back(rootObjects[i]); 
					rootObjects.erase(rootObjects.begin() + i);
					break;
				}
		}
		else
			for (size_t i = 0; i < currentParent->getSize(); i++)
				if (currentParent->items[i]->getName() == name) {
					cutObject.push_back(currentParent->items[i]);
					currentParent->remove(currentParent->items[i]);
					break;
				}
	}

	void paste() {
		auto cutElement = cutObject.back();
		cutObject.pop_back();
		if (!currentParent)
			rootObjects.push_back(cutElement);
		else {
			currentParent->add(cutElement);
			cutElement->setParent(currentParent);
		}
	}

	void createShortcut(std::string name) {
		if (!shortcuts) {
			shortcuts = std::make_shared<Shortcuts>();
			std::shared_ptr<FileSystemObject> newObject = shortcuts;
			rootObjects.push_back(shortcuts);
		}
		if (!currentParent) {
			for (size_t i = 0; i < rootObjects.size(); i++)
				if (rootObjects[i]->getName() == name) {
					shortcuts->add(rootObjects[i]); break;
				}
		} else
			for (size_t i = 0; i < currentParent->getSize(); i++)
				if (currentParent->items[i]->getName() == name) {
					shortcuts->add(currentParent->items[i]); break;
				}
	}

	void navigate(std::string path) {
		if (path == "..") {
			// return one level up
			std::shared_ptr<Directory> temp = nullptr;
			std::shared_ptr<Directory> parent = nullptr;
			if (currentParent->getParent().lock())
				temp = std::dynamic_pointer_cast<Directory>(currentParent->getParent().lock());
			if (!temp)
				currentParent = nullptr;
			else {
				currentParent = temp;
				/*parent = std::dynamic_pointer_cast<Directory>(temp);
				if (parent)
					currentParent->setParent(parent);*/
			}
		}
		else {
			// find the folder and go down
			if (!currentParent) {
				for (size_t i = 0; i < rootObjects.size(); i++)
					if (rootObjects[i]->getName() == path) {
						std::shared_ptr<Directory> temp = std::dynamic_pointer_cast<Directory>(rootObjects[i]);
						//currentParent->setParent();
						currentParent = temp; break;
					}
			} else 
			for (size_t i = 0; i < currentParent->getSize(); i++)
				if (currentParent->items[i]->getName() == path) {
					std::shared_ptr<Directory> temp = std::dynamic_pointer_cast<Directory>(currentParent->items[i]);
					std::shared_ptr<Directory> parent = currentParent;
					currentParent = temp;
					currentParent->setParent(parent);
					break;
				}
		}
	}
};

#endif // !EXPLORER_H