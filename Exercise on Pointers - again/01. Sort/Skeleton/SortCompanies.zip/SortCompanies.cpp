#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include "Company.h"

int main() {
	std::string name;
	int id;
	std::vector<Company*> companyVec;

	while (std::cin >> name && name != "end") {
		std::cin >> id;

		companyVec.push_back(new Company(id, name));
	}
	std::string sortInd;
	std::cin >> sortInd;

	if (sortInd == "id") {
		std::sort(companyVec.begin(), companyVec.end(), [](const Company* a, const Company* b) {
			return a->getId() < b->getId();
			});
	}
	else {
		std::sort(companyVec.begin(), companyVec.end(), [](const Company* a, const Company* b) {
			return a->getName() < b->getName();
			});
	}

	for (size_t i = 0; i < companyVec.size(); i++) {
		std::cout << companyVec[i]->toString() << std::endl;
	}

	return 0;
}