#include <iostream>
#include <vector>
#include <string>
#include <sstream>

#include "Range.h"

std::vector<Range> readFromInput() {
    std::string input;
    std::vector<Range> toReturn;
    while (std::getline(std::cin, input) && input != ".") {
        std::istringstream in(input);
        int numberfrom = 0, numberTo = 0;
        in >> numberfrom >> numberTo;
        toReturn.emplace_back(numberfrom, numberTo);
    }
    
    return toReturn;
}

bool lessThanTo(Range* a, int number) {
    return number <= (*a).getTo() ;
}

bool moreThanFrom(Range* a, int number) {
    return (*a).getFrom() <= number;
}

int main()
{
    //std::vector <Range> from_to = readFromInput();

    //////////////////////////////

    std::vector<std::string> lines;
    std::string line;
    while (getline(std::cin, line) && line != ".") {
        lines.push_back(line);
    }

    int numRanges = lines.size();
    std::vector <Range*> rangesPtrs;
    for (size_t i = 0; i < lines.size(); i++) {
        std::string line = lines[i];

        std::istringstream lineIn(line);
        int from;
        int to;
        lineIn >> from >> to;

        Range* ob = new Range(from, to);
        rangesPtrs.push_back(ob);
    }

    ////////////////////////////////////

    std::string input;
    while (std::getline(std::cin, input) && input != ".") {
        std::istringstream in(input);
        int numberToCheck = 0;
        in >> numberToCheck;
    
        // check func
        bool inside = false;
        /////////////
        //checknum(rangesPtrs, rangesPtrs + numRanges, lessThanTo);
        //checknum(rangesPtrs, rangesPtrs + numRanges, moreThanFrom);
        ////////////
        //Range** rangesEnd = rangesPtrs + numRanges;
        for (std::vector<Range*>::iterator it = rangesPtrs.begin(); it != rangesPtrs.end(); it++) {
            if (moreThanFrom(*it, numberToCheck) && lessThanTo(*it, numberToCheck)) {
                std::cout << "in" << std::endl;
                inside = true;
                break;
            }
        }
            if (!inside)
                std::cout << "out" << std::endl;

            
    }

    for (std::vector<Range*>::iterator it = rangesPtrs.begin(); it != rangesPtrs.end(); it++) {
        delete* it;
        *it = nullptr;
    }

    return 0;
}

