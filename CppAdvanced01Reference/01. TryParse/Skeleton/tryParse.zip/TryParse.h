#ifndef TRYPARSE_H
#define TRYPARSE_H
#include <string>

using namespace std;

#pragma once
bool tryParse(const string& str, int& x);

#endif // !TRYPARSE_H

