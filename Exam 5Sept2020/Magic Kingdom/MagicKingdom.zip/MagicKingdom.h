#pragma once
#ifndef MAGIC_H
#define MAGIC_H

#include <iostream>
#include <sstream>
#include "Struct.h"
#include <map>

class MagicKingdom {
    
    
public:
    std::map<int, std::string> AntiMags;
    std::map<int, std::string, std::greater<int> > Magicians, Commoner;
    MagicKingdom operator<<(const Villager& v) {
        std::string name = v.name;
        int power = v.power;
        std::string magicItem = v.magicItem;

        std::string str = name + " - " + magicItem;

        if (power < 0) {
            this->AntiMags[power] = str;
        }
        else if (power >= 100)
            this->Magicians[power] = str;
        else
            this->Commoner[power] = str;


        return *this;
    }

    void printAll() {
        //if (!AntiMags.empty()) {
            std::cout << "Anti-Mages:" << std::endl;
            for (std::pair<int, std::string> p : AntiMags) {
                std::cout << p.second << std::endl;
            }
        
        //if (!Commoner.empty()) {
            std::cout << "Commoners:" << std::endl;
            for (std::pair<int, std::string> p : Commoner) {
                std::cout << p.second << std::endl;
            }
        
        //if (!Magicians.empty()) {
            std::cout << "Mages:" << std::endl;
            for (std::pair<int, std::string> p : Magicians) {
                std::cout << p.second << std::endl;
            }
        
    }
};


#endif // !MAGIC_H
